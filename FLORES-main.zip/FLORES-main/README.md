# FLORES HTML Y CSS
-Flower code from: https://codepen.io/Nilver-TI/pen/PoroWJa

# Descripción
El código de la flor sigue la tendencia de TikTok. La página web es totalmente responsiva y puedes ajustar los estilos directamente en el archivo CSS --> style.css

# Autor
- Flower Code: Md Usman Ansari (@MdUsmanAnsari)
- Index Code: NILVER TI

Agradecimientos a CodePen y Md Usman Ansari
